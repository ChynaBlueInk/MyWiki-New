"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { getCurrentUser, signOut, AuthUser } from "@aws-amplify/auth";

const NavBar = () => {
  const [user, setUser] = useState<AuthUser | null>(null);

  useEffect(() => {
    const checkUser = async () => {
      try {
        const currentUser = await getCurrentUser();
        setUser(currentUser as AuthUser);
      } catch (error) {
        setUser(null);
      }
    };
    checkUser();
  }, []);

  const handleSignOut = async () => {
    await signOut();
    setUser(null);
  };

  return (
    <nav className="navbar">
      <Link href="/">Home</Link>
      <Link href="/tools">Tools</Link>
      <Link href="/add-tool">Add Tool</Link>
      <Link href="/about">About</Link>
      <Link href="/contact">Contact</Link>

      {user ? (
        <>
          <button onClick={handleSignOut}>Logout</button>
        </>
      ) : (
        <>
          <Link href="/signup">
            <button>Sign Up</button>
          </Link>
          <Link href="/login">
            <button>Login</button>
          </Link>
        </>
      )}
    </nav>
  );
};

export default NavBar;
